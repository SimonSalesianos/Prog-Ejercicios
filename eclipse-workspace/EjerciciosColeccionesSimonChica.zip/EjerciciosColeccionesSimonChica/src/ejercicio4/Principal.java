package ejercicio4;

import java.util.ArrayList;
import java.util.List;


public class Principal {

	public static void main(String[] args) {

		
		
        List<Empleado> listaEmpleados = new ArrayList<>();

		
		
		
		
		
	}

}
